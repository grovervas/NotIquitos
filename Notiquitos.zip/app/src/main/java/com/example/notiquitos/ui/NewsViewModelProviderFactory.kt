package com.example.notiquitos.ui

import androidx.lifecycle.ViewModelProvider
import com.example.notiquitos.db.NewsViewModel
import com.example.notiquitos.repository.NewsRepository


class NewsViewModelProviderFactory {

}

/*
class NewsViewModelProviderFactory(
    val newsRepository: NewsRepository
) : ViewModelProvider.Factory {

    override fun <T : androidx.lifecycle.ViewModel?> create(modelClass: java.lang.Class<T>): T {
        return NewsViewModel(newsRepository) as T
    }
}

*/