package com.example.notiquitos.ui.fragments

import androidx.fragment.app.Fragment
import com.example.notiquitos.R

class ArticleFragment : Fragment(R.layout.fragment_article) {
}