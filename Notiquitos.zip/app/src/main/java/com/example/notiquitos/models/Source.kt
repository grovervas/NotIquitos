package com.example.notiquitos.models

data class Source(
    val id: String,
    val name: String
)