package com.example.notiquitos.ui.fragments

import androidx.fragment.app.Fragment
import com.example.notiquitos.R
import com.example.notiquitos.databinding.ActivityMainBinding

class BreakingNewsFragment : Fragment(R.layout.fragment_breaking_news) {


}