package com.example.notiquitos.db

import androidx.lifecycle.ViewModel
import com.example.notiquitos.repository.NewsRepository

class NewsViewModel {

}