package com.example.notiquitos.repository

import com.example.notiquitos.db.ArticleDatabase

class NewsRepository(
    val db: ArticleDatabase
) {
}