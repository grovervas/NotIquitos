package com.example.notiquitos.util

class Constants {
    companion object {
        const val API_KEY = "73047b5db7a3406d82105fdab00499e9"
        const val BASE_URL = "https://newsapi.org"
    }
}