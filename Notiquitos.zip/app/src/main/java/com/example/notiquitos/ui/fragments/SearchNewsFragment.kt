package com.example.notiquitos.ui.fragments

import androidx.fragment.app.Fragment
import com.example.notiquitos.R

class SearchNewsFragment : Fragment(R.layout.fragment_search_news) {
}